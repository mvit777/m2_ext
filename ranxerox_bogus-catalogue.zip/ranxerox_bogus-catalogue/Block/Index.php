<?php
namespace Ranxerox\Bogus_Catalogue\Block;

class Index extends \Magento\Framework\View\Element\Template{
		
	/*public function doSomtething(){
		return $this->getData();
	}*/
}