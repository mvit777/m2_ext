<?php
namespace Ranxerox\Fica_Catalogue\Block;

class Index extends \Magento\Framework\View\Element\Template{
		
	/*public function doSomtething(){
		return $this->getData();
	}*/
}